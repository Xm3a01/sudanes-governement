@extends('dashboard.metronic')
@section('content')

 <!-- BEGIN PAGE HEAD-->
 <div class="page-head">
        <!-- BEGIN PAGE TITLE -->
        <div class="page-title">
            <h1> جدول الوظائف
            </h1>
        </div> 
    </div>
    <!-- END PAGE HEAD-->
    <!-- BEGIN PAGE BREADCRUMB -->
    <ul class="page-breadcrumb breadcrumb">
        <li>
            <a href="index.html">الرئيسية</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <span class="active">إضافة وظيفة جديدة  </span>
        </li>
    </ul>
    <!-- END PAGE BREADCRUMB -->
    <!-- BEGIN PAGE BASE CONTENT --> 
<div class="row"> 
<div class="col-md-12 ">
    <!-- BEGIN SAMPLE FORM PORTLET-->
    <div class="portlet light bordered">
            <div class="portlet-title">
                    <div class="caption">
                        <i class="icon-social-dribbble font-green hide"></i>
                        <span class="caption-subject font-dark bold uppercase">إضافة وظيفة جديدة</span>
                    </div>
                 </div> 
        <div class="portlet-body form">
            <form class="form-horizontal" role="form" autocomplete="off" method="POST" action="{{route('jobs.store')}}">
                @csrf
                <div class="form-body"> 
                  <input  type="hidden" name="owner_id" value="{{$owner->id}}">
                    <div class="form-group">
                            <label class="col-md-3 control-label">الدور الوظيفي</label>
                            <div class="col-md-6">
                                <input list ="role" id="inputState" class="form-control" name="role">
                                </div>
                                <datalist id="role">   
                                  @foreach ($roles as $role)  
                                  <option value=" {{ $role->ar_name }}">
                                  @endforeach
                                </datalist>
                        </div>

                        <div class="form-group">
                                <label class="col-md-3 control-label">المستوى الوظيفي</label>
                                <div class="col-md-6">
                                   <input list ="level" id="inputState" class="form-control" name="level">
                                    </div>
                                      <datalist id="level">   
                                        @foreach ($levels as $level)  
                                        <option value=" {{ $level->ar_name }}">
                                        @endforeach
                                      </datalist>
                            </div>

                    <div class="form-group">
                            <label class="col-md-3 control-label">اختر الدولة</label>
                            <div class="col-md-6">
                                    <input list="country" name="country" id="inputState" class="form-control" autocomplete="off">
                                </div>
                                <datalist id="country" dir="rtl" >
                                  @foreach ($countries as $country)    
                                  <option value="{{ $country->ar_name }}">
                                  @endforeach
                                  </datalist>
                        </div>

                    <div class="form-group">
                            <label class="col-md-3 control-label">اختر المدينة</label>
                            <div class="col-md-6">
                                <input list="city" name="city" id="inputState" class="form-control" placeholder="المدينه الحاليه" autocomplete="off">
                                    </div>
                                    <datalist id="city" dir="rtl" >
                                      @foreach ($cities as $city)    
                                      <option value="{{ $city->ar_name }}">
                                      @endforeach
                                      </datalist>
                        </div>
                    
                      <div class="form-group">
                            <label class="col-md-3 control-label"> سنين الخبرة المطلوبة</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control  " placeholder="مثال: 1 شهر و2 سنة " name="experinse">
                             </div>
                        </div>
                    
                        <div class="form-group">
                                <label class="col-md-3 control-label">التخصص الاساسي</label>
                                <div class="col-md-6">
                                    <input list="special" name="special" id="inputState" class="form-control" placeholder="التخصص " autocomplete="off">
                                    </div>
                                    <datalist id="special" dir="rtl" >
                                      @foreach ($specials as $special)    
                                      <option value="{{ $special->ar_name }}">
                                      @endforeach
                                      </datalist>
                            </div>

                            <div class="form-group">
                                <label class="col-md-3 control-label">التخصص الفرعي</label>
                                <div class="col-md-6">
                                    <input list ="subspecial" id="inputState" class="form-control" name="sub_special">
                                        </div>
                                        <datalist id="subspecial">
                                          @foreach ($sub_specials as $special)     
                                              <option value=" {{ $special->ar_name }}">
                                          @endforeach
                                        </datalist>
                            </div>
                        
                        <div class="form-group">
                                <label class="col-md-3 control-label">حالة العمل</label>
                                <div class="col-md-6">
                                    <select class="form-control" name="status">
                                        <option value="Full time">دوام كامل</option>
                                        <option value="Part time">دوام جزئي</option>
                                    </select>
                                </div>
                            </div>
                    
                            <div class="form-group ">
                                    <label class="col-md-3 control-label">الراتب</label>
                                    <div class="col-md-6">
                                        <input type="text" class="form-control  " placeholder="مثال: 2500 - 5000" name="selary">
                                      </div>
                                </div>

                            <div class="form-group">
                                    <label class="col-md-3 control-label">الوصف الوظيفي</label>
                                    <div class="col-md-6">
                                        <textarea class="form-control" rows="3" name="ar_description"> </textarea>
                                    </div>
                                </div>
                                 <div class="form-group">
                                    <label class="col-md-3 control-label">الوصف الوظيفي باللغة الانجليزية</label>
                                    <div class="col-md-6">
                                        <textarea class="form-control" rows="3" name="description"> </textarea>
                                    </div>
                                </div>
                                <div class="form-actions">
                                <div class="row">
                                    <div class="col-md-offset-3 col-md-9">
                                        <button type="submit" class="btn green">حفظ</button>
                                        <button type="button" class="btn default">إلغاء</button>
                                    </div>
                                </div>
                            </div>
                            </form>
                        </div>
                    </div> 
                </div>
            </div>

            <!-- END PAGE BASE CONTENT -->
                         


@endsection