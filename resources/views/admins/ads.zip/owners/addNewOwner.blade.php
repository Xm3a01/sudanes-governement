@extends('dashboard.metronic')

@section('title')
    اضافة صاحب عمل
@endsection
@section('content')


   <!-- BEGIN PAGE HEAD-->
   <div class="page-head">
        <!-- BEGIN PAGE TITLE -->
        <div class="page-title">
            <h1> ادارة اصحاب العمل 
            </h1>
        </div> 
    </div>
    <!-- END PAGE HEAD-->
    <!-- BEGIN PAGE BREADCRUMB -->
    <ul class="page-breadcrumb breadcrumb">
        <li>
            <a href="index.html">الرئيسية</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <span class="active">إضافة صاحب عمل جديد  </span>
        </li>
    </ul>
    <!-- END PAGE BREADCRUMB -->
    <!-- BEGIN PAGE BASE CONTENT --> 
<div class="row"> 
<div class="col-md-12 ">
    <!-- BEGIN SAMPLE FORM PORTLET-->
    <div class="portlet light bordered">
            <div class="portlet-title">
                    <div class="caption">
                        <i class="icon-social-dribbble font-green hide"></i>
                        <span class="caption-subject font-dark bold uppercase">إضافة صاحب عمل جديد</span>
                    </div>
                 </div> 
        <div class="portlet-body form">
            <form class="form-horizontal" role="form" method="POST" action="{{route('companies.store')}}" enctype="multipart/form-data">
                @csrf
                <input type="hidden" name="label" value="admin">
                <input type="hidden" name="select" value="owner">
                <div class="form-body">
                        <div class="form-group">
                                <label class="col-md-3 control-label">الاسم</label>
                                <div class="col-md-3">
                                    <input type="text" class="form-control" placeholder="الاسم الاول " name="ar_name">
                                  </div>
                                   <div class="col-md-3">
                                    <input type="text" class="form-control" placeholder="الاسم الاخير " name="ar_last_name">
                                  </div>
                            </div>
                        <div class="form-group">
                                <label class="col-md-3 control-label">البريد اللاكتروني</label>
                                <div class="col-md-6">
                                    <input type="email" class="form-control" placeholder="البريد اللاكتروني " name="email">
                                  </div>
                            </div>
                            <div class="form-group">
                                    <label class="col-md-3 control-label">كلمة السر</label>
                                    <div class="col-md-6">
                                        <input type="password" class="form-control" placeholder="كلمة السر" name="password">
                                      </div>
                                </div>
                                <div class="form-group">
                                        <label class="col-md-3 control-label">الهــاتف</label>
                                        <div class="col-md-6">
                                            <input type="text" class="form-control" placeholder="الهاتف" name="phone">
                                          </div>
                                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">إسم الشركة</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" placeholder="ادخل إسم الشركة " name="company_name">
                          </div>
                    </div>
                     <div class="form-group">
                        <label class="col-md-3 control-label">Company Name</label>
                        <div class="col-md-6">
                            <input type="text" class="form-control" placeholder=" ادخل إسم الشركة باللغة الانجليزية" name="company_name_en">
                          </div>
                    </div>
                    <div class="form-group">
                            <label class="col-md-3 control-label"> بريد العمل الإلكتروني / عنوان URL</label>
                            <div class="col-md-6">
                                <input type="email" class="form-control" placeholder="ادخل  بريد العمل الإلكتروني / عنوان URL " name="company_email">
                              </div>
                        </div>

                    <div class="form-group">
                            <label class="col-md-3 control-label">الدور الوظيفي</label>
                            <div class="col-md-6">
                                <input list ="role" id="inputState" autocompalete ="off" class="form-control" name="role">
                                </div>
                                <datalist id="role">   
                                  @foreach ($roles as $role)  
                                  <option value=" {{ $role->ar_name  }}">
                                  @endforeach
                                </datalist>
                        </div> 
                    <div class="form-group">
                            <label class="col-md-3 control-label">اختر الدولة</label>
                            <div class="col-md-6">
                                <input list ="country" id="inputState" autocompalete ="off" class="form-control" name="country">
                                </div>
                                <datalist id="country">   
                                  @foreach ($countries as $country)  
                                  <option value=" {{ $country->ar_name }}">
                                  @endforeach
                                </datalist>
                        </div>
                        <div class="form-group">
                            <label class="col-md-3 control-label">اختر المدينه</label>
                            <div class="col-md-6">
                                <input list ="city" id="inputState" autocompalete ="off" class="form-control" name="city">
                                </div>
                                <datalist id="city">   
                                  @foreach ($cities as $city)  
                                  <option value=" {{ $city->ar_name }}">
                                  @endforeach
                                </datalist>
                        </div>

                        <div class="form-group">
                            <label class="col-md-3 control-label">الجنس</label>
                            <div class="col-md-6">
                                <select class="form-control" name="gender">
                                    <option disabled selected> الجنس</option>    
                                    <option value="Maile">ذكر</option>
                                    <option value="Femaile">انثى</option>
                                </select>
                            </div>
                        </div>
                      
                            <div class="form-group">
                                    <label class="col-md-3 control-label">الوصف الوظيفي</label>
                                    <div class="col-md-6">
                                        <textarea class="form-control" rows="3" name="ar_description"></textarea>
                                    </div>
                                </div>
                    
                                <div class="form-group">
                                        <label for="exampleInputFile" class="col-md-3 control-label">الشعار</label>
                                        <div class="col-md-6">
                                            <input type="file" id="exampleInputFile" name="logo">
                                            <p class="help-block">ملف (اختياري)</p>
                                        </div>
                                    </div> 
                                         <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-offset-3 col-md-9">
                                                    <button type="submit" class="btn green">حفظ</button>
                                                    <button type="button" class="btn default">إلغاء</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div> 
                        </div>
                    </div>



@endsection
